
var message = "Welcome to BiviSoft"
alert(message);
