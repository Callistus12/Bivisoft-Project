

	function myFunctions() {
		document.getElementById("demos1").innerHTML = "Hello king cally";
		document.getElementById("demos2").innerHTML = "how are you doing";
	}
	alert("works!");