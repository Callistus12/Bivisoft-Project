﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Calischool.Data;
using Calischool.Models;
using Microsoft.AspNetCore.Authorization;
using Calischool.Services;
using Microsoft.AspNetCore.Identity;
using Calischool.ViewModel;

namespace Calischool.Controllers
{

    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly IAccountServices _accountServices;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signManager;
        public AdminController(ApplicationDbContext db, IAccountServices accountServices, UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signManager)
        {
            _db = db;
            _accountServices = accountServices;
            _userManager = userManager;
            _signManager = signManager;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        // [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult Dashboard()
        {
            var applicationUser = new List<ApplicationUser>();
            var users = _db.StudentRegisters.Where(a => a.FirstName != null && a.Email != null && a.Deactiveted != true ).ToList();

            if (users.Count > 0)
            {
                return View(users);
            }
            return View(applicationUser);
        }
        
        [HttpGet]
        public IActionResult Edit()
        {
            var userName = User.Identity.Name;

            var detailsOfMyUser = _accountServices.GetUserDetailsForEdit(userName);

            return View(detailsOfMyUser);

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateTheEditedUserDetails(RegisterViewModel newlyeditedUserRecord)
        {
            if (newlyeditedUserRecord == null)
            {
                return null;
            }
            var editingUserDetails = _accountServices.UpdateTheEditedUserDetails(newlyeditedUserRecord);
             if (editingUserDetails)
             {
                return RedirectToAction("Index");
             }
            return View(newlyeditedUserRecord);
        }
        [HttpGet]
        public IActionResult Delete(string userId)
        {
            var userDetail = _userManager.FindByIdAsync(userId).Result;

            if (userDetail != null)
            {
                userDetail.Deactiveted = true;

                _db.Update(userDetail);
                _db.SaveChanges();
                return RedirectToAction("Dashboard");
            }
           return View();
        }

        
        public IActionResult AddAdminToRole(string userToAdmin)
        {
            var userDetail = _userManager.FindByIdAsync(userToAdmin).Result;
            if (userDetail != null)
            {
                _userManager.AddToRoleAsync(userDetail, "Admin");
                return RedirectToAction("Dashboard");
            }
           return View();
        }
        public IActionResult Search(string userDetails)
        {
            var findUserFromTable = _accountServices.SearchUserFromTheTable(userDetails);
            if (findUserFromTable != null)
            {
                return View(userDetails);
            }
            return null;
        }
    }
}

   



