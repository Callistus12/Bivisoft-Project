﻿using Calischool.Models;
using Calischool.ViewModel;

namespace Calischool.Services
{
    public interface IAccountServices
    {
        ApplicationUser Login(LoginViewModel loginViewModel);
        ApplicationUser RegisterUserDetails(RegisterViewModel obj);
        RegisterViewModel GetUserDetailsForEdit(string userName);
        IQueryable<ApplicationUser> SearchUserFromTheTable(string userDetailToFetch);
        bool UpdateTheEditedUserDetails(RegisterViewModel newlyeditedUserRecord);
    }
}
