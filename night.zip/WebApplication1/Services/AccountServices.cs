﻿using Calischool.Data;
using Calischool.Models;
using Calischool.ViewModel;
using Microsoft.AspNetCore.Identity;

namespace Calischool.Services
{
    public class AccountServices: IAccountServices
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signManager;
        
        public AccountServices(ApplicationDbContext db, UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signManager)
        {
            _db = db;
            _userManager = userManager;
            _signManager = signManager;
        }
        // login the user
        public ApplicationUser Login(LoginViewModel loginViewModel)
        {

            
            if (loginViewModel.Email == null)
            {
                return null;
            }
            var getUserEmail = _userManager.FindByEmailAsync( loginViewModel.Email ).Result;
            if (getUserEmail != null)
            {
                var userCheck = _signManager.CanSignInAsync(getUserEmail).Result;
                if (userCheck)
                {
                   var checkUser = _signManager.PasswordSignInAsync(getUserEmail, loginViewModel.Password, true, false).Result;
                    if (checkUser.Succeeded) 
                    {
                        return getUserEmail;
                    }
                    return null;
                }
            }
            return null;
        }
        // registering the user as a new member
        public ApplicationUser RegisterUserDetails(RegisterViewModel obj)
        {
            var newdb = new ApplicationUser
            {
                UserName = obj.Email,
                Email = obj.Email,
                Gender = obj.Gender,
                FirstName = obj.FirstName,
                LastName = obj.LastName,
                PhoneNumber = obj.PhoneNumber,
            };
          
           return newdb;
        }
        // Getting existing User from the usermanager.
        public RegisterViewModel GetUserDetailsForEdit(string userName)
        {
            var userDetail = _userManager.FindByNameAsync(userName).Result;
            if (userDetail != null)
            {
                var newStudent = new RegisterViewModel
                {
                    Email = userDetail.Email,
                    Gender = userDetail.Gender,
                    FirstName = userDetail.FirstName,
                    LastName = userDetail.LastName,
                    MiddleName = userDetail.MiddleName,
                   PhoneNumber = userDetail.PhoneNumber,
                    DateOfBirth = userDetail.DateOfBirth,
                    RedsidentAddress = userDetail.RedsidentAddress,
                    Country = userDetail.Country,
                    State = userDetail.State,
                    LGA = userDetail.LGA,
                    Qualification = userDetail.Qualification,
                    Displine = userDetail.Displine,
                };
                 return newStudent;
            }
            return null;
        }
       // Searching student from the student table.
        public IQueryable<ApplicationUser> SearchUserFromTheTable(string userDetailToFetch)
        {
            var SearchUserFromTheTable = from A in _db.StudentRegisters
                         select A;
            if (!string.IsNullOrEmpty(userDetailToFetch))
            {
                SearchUserFromTheTable = SearchUserFromTheTable.Where(a => a.FirstName.Contains(userDetailToFetch) && a.Deactiveted != true);
                 
                return SearchUserFromTheTable;
            }
            return null;
        }

        // updating the ApplicationUser Details
        public bool UpdateTheEditedUserDetails(RegisterViewModel newlyeditedUserRecord)
        {
            try
            {
                var usersOldRecord = _userManager.FindByEmailAsync(newlyeditedUserRecord.Email).Result;
                if (usersOldRecord != null)
                {
                    usersOldRecord.Country = newlyeditedUserRecord.Country;
                    usersOldRecord.Displine = newlyeditedUserRecord.Displine;
                    usersOldRecord.DateOfBirth = newlyeditedUserRecord.DateOfBirth;
                    usersOldRecord.FirstName = newlyeditedUserRecord.FirstName;
                    usersOldRecord.MiddleName = newlyeditedUserRecord.MiddleName;
                    usersOldRecord.PhoneNumber = newlyeditedUserRecord.PhoneNumber;
                    usersOldRecord.LastName = newlyeditedUserRecord.LastName;
                    usersOldRecord.Email = newlyeditedUserRecord.Email;
                    usersOldRecord.Gender = newlyeditedUserRecord.Gender;
                    usersOldRecord.State = newlyeditedUserRecord.State;
                    usersOldRecord.Qualification = newlyeditedUserRecord.Qualification;
                    usersOldRecord.RedsidentAddress = newlyeditedUserRecord.RedsidentAddress;
                    usersOldRecord.LGA = newlyeditedUserRecord.LGA;
                    usersOldRecord.PhoneNumber = newlyeditedUserRecord.PhoneNumber;

                    _db.StudentRegisters.Update(usersOldRecord);
                    _db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }

           
        }
    }

}

   